#include <stdio.h>
#include "output.h"

void output_score(float score1, float score2, float score)
{
	printf("score1: %.1f, score2: %.1f, score: %.1f\n",
	        score1, score2, score);
}
