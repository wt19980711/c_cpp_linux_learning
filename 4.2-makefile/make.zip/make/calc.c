#include "calc.h"

float calc_score(float score1, float score2)
{
	return score1 * 0.5 + score2 * 0.5;
}
