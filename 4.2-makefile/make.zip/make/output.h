#ifndef _OUTPUT_H
#define _OUTPUT_H

/* score1: 考试成绩
 * score2: 平时成绩
 * score:  最终成绩
 */
void output_score(float score1, float score2, float score);

#endif /* _OUTPUT_H */
