#ifndef _CALC_H
#define _CALC_H

/* score1为考试成绩，score2为平时成绩 */
float calc_score(float score1, float score2);

#endif /* _CALC_H */
